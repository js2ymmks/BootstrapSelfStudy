/******************************************
 * テンプレートファイル読み込み
 ******************************************/
Promise.all([
  fetch("../../partials/header.html").then((r) => r.text()),
  fetch("../../partials/date.html").then((r) => r.text()),
  fetch("../../partials/footer.html").then((r) => r.text()),
  fetch("../../partials/modal.html").then((r) => r.text()),
  fetch("../../partials/drower-menu.html").then((r) => r.text()),
])
  .then(([headerHtml, dateHtml, footerHtml, modalHtml, drawerHtml]) => {
    document.querySelector(".content-header").innerHTML = headerHtml;
    document.querySelector(".content-date").innerHTML = dateHtml;
    document.querySelector(".content-footer").innerHTML = footerHtml;
    document.querySelector(".content-modal").innerHTML = modalHtml;
    document.querySelector(".content-drawer").innerHTML = drawerHtml;
  })
  .catch((err) => {
    console.error("Failed to load partials:", err);
  });

/******************************************
 * JSON取得（ブラケット版）
 ******************************************/
const getJsonValue = (propertyPath) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : null;
  } catch (e) {
    data = null;
  }

  if (!data) return undefined;

  // ブラケット → ドット記法
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let prop of props) {
    if (current[prop] === undefined) return undefined;
    current = current[prop];
  }

  return current;
};

/******************************************
 * JSON更新（ブラケット版）
 ******************************************/
const setJsonValue = (propertyPath, value) => {
  const storedJson = sessionStorage.getItem("appData");
  let data;

  try {
    data = storedJson ? JSON.parse(storedJson) : {};
  } catch (e) {
    data = {};
  }

  // ブラケット記法をドット記法に変換
  // "buttons[0].label" → "buttons.0.label"
  const normalizedPath = propertyPath.replace(/\[(\d+)\]/g, ".$1");

  const props = normalizedPath.split(".");
  let current = data;

  for (let i = 0; i < props.length - 1; i++) {
    const prop = props[i];

    // 数字 → 配列アクセス
    const index = Number(prop);
    const isIndex = !isNaN(index);

    if (isIndex) {
      if (!Array.isArray(current)) {
        current = [];
      }
      if (current[index] === undefined) {
        current[index] = {};
      }
      current = current[index];
    } else {
      if (!current[prop] || typeof current[prop] !== "object") {
        current[prop] = {};
      }
      current = current[prop];
    }
  }

  // 最終プロパティ
  const lastProp = props[props.length - 1];
  const lastIndex = Number(lastProp);

  if (!isNaN(lastIndex)) {
    if (!Array.isArray(current)) current = [];
    current[lastIndex] = value;
  } else {
    current[lastProp] = value;
  }

  sessionStorage.setItem("appData", JSON.stringify(data));
};

/******************************************
 * 運転モード選択ボタン, 操作パネル表示処理
 ******************************************/
const driveModeSwitchBtnAndSettingPanelOperation = () => {
  let currentMode = getJsonValue("currentMode");
  document.getElementById("driveModeSwitchBtn").classList.add(getJsonValue(`driveModeSelectBtn.${currentMode}.style`));
  document.getElementById("currentModeLabel").innerText = getJsonValue(`driveModeSelectBtn.${currentMode}.label`);
  document.getElementById("currentModeIcon").src = getJsonValue(`driveModeSelectBtn.${currentMode}.icon`);
  document.getElementById("temp-display").className = getJsonValue(`driveModeSelectBtn.${currentMode}.settingDisplay`);
};

/******************************************
 * フッターアイコン初期表示
 * アイコンをクリックするとページが切り替わるため、初期表示のみで対応
 ******************************************/
window.addEventListener("load", () => {
  setTimeout(() => {
    // 1. 初期表示
    document.getElementById("footer-mymu").src = getJsonValue(
      "footerIconStatus.mymu"
    );
    document.getElementById("footer-basic").src = getJsonValue(
      "footerIconStatus.basic"
    );
    document.getElementById("footer-schedule").src = getJsonValue(
      "footerIconStatus.schedule"
    );
    document.getElementById("footer-other").src = getJsonValue(
      "footerIconStatus.other"
    );
    document
      .getElementById(`footer-${getJsonValue("currentPage")}-txt`)
      .classList.add("active");

    document.querySelectorAll(".footer-button").forEach((btn) => {
      btn.addEventListener("click", () => {
        // 2. リセット
        setJsonValue(
          "footerIconStatus.mymu",
          "../assets/img/icon-footer-mymu.svg"
        );
        setJsonValue(
          "footerIconStatus.basic",
          "../assets/img/icon-footer-basic.svg"
        );
        setJsonValue(
          "footerIconStatus.schedule",
          "../assets/img/icon-footer-schedule.svg"
        );
        setJsonValue(
          "footerIconStatus.other",
          "../assets/img/icon-footer-other.svg"
        );

        // 3. JSON更新
        setJsonValue(
          `footerIconStatus.${btn.dataset.appPage}`,
          `../assets/img/icon-footer-${btn.dataset.appPage}-active.svg`
        );
        setJsonValue("currentPage", `${btn.dataset.appPage}`);
        // 4. 表示更新
        document.getElementById(`footer-${btn.dataset.appPage}`).src =
          getJsonValue(`footerIconStatus.${btn.dataset.appPage}`);
      });
    });
  }, 100);
});

/******************************************
 * 温度・湿度・送風 設定処理（完全版）
 ******************************************/

// =========================
// パラメータ
// =========================

// --- 温度（cooling / heating）---
const MIN_TEMP = 16.0;
const MAX_TEMP = 31.0;
const TEMP_STEP = 0.5;
const TEMP_INITIAL = 23.0;
const TEMP_UNIT = "℃";

// --- 湿度（dehumidifying）---
const MIN_HUMIDITY = 40;
const MAX_HUMIDITY = 70;
const HUMIDITY_STEP = 10;
const HUMIDITY_INITIAL = 50;
const HUMIDITY_UNIT = "%";

// --- 送風（perflation）---
const PERFLATION_MODES = ["弱", "標準", "強"];
const PERFLATION_INITIAL_INDEX = 1;

// =========================
// DOM
// =========================
const btnDown = document.getElementById("btnDown");
const btnUp = document.getElementById("btnUp");
const tempIntEl = document.getElementById("tempInt");
const tempDecEl = document.getElementById("tempDec");
const tempUnitEl = document.getElementById("tempUnit");

// =========================
// 状態（値そのもの）
// =========================
let currentTemp = TEMP_INITIAL;
let currentHumidity = HUMIDITY_INITIAL;
let currentPerflationIndex = PERFLATION_INITIAL_INDEX;

// =========================
// 共通：丸め & クランプ
// =========================
function clampValue(value, min, max, step) {
  const rounded = Math.round(value / step) * step;
  return Math.min(max, Math.max(min, rounded));
}

// =========================
// 表示更新（JSONを正として参照）
// =========================
function updateDisplay() {
  const currentMode = getJsonValue("currentMode");

  // ---------- 表示 ----------
  if (currentMode === "cooling" || currentMode === "heating") {
    const fixed = currentTemp.toFixed(1);
    const [intPart, decPartRaw] = fixed.split(".");
    tempIntEl.textContent = intPart;
    tempDecEl.textContent = "." + decPartRaw;
    tempUnitEl.innerText = TEMP_UNIT;
  }

  if (currentMode === "dehumidifying") {
    tempIntEl.textContent = currentHumidity;
    tempDecEl.textContent = "";
    tempUnitEl.innerText = HUMIDITY_UNIT;
  }

  if (currentMode === "perflation") {
    tempIntEl.textContent = PERFLATION_MODES[currentPerflationIndex];
    tempDecEl.textContent = "";
    tempUnitEl.innerText = "";
  }

  // ---------- ボタン制御 ----------
  let isMin = false;
  let isMax = false;

  if (currentMode === "cooling" || currentMode === "heating") {
    isMin = currentTemp <= MIN_TEMP;
    isMax = currentTemp >= MAX_TEMP;
  }

  if (currentMode === "dehumidifying") {
    isMin = currentHumidity <= MIN_HUMIDITY;
    isMax = currentHumidity >= MAX_HUMIDITY;
  }

  if (currentMode === "perflation") {
    isMin = currentPerflationIndex <= 0;
    isMax = currentPerflationIndex >= PERFLATION_MODES.length - 1;
  }

  btnDown.classList.toggle("disabled", isMin);
  btnUp.classList.toggle("disabled", isMax);
}

// =========================
// 値変更
// =========================
function changeValue(stepDiff) {
  const currentMode = getJsonValue("currentMode");

  // --- 温度 ---
  if (currentMode === "cooling" || currentMode === "heating") {
    const next = clampValue(
      currentTemp + stepDiff * TEMP_STEP,
      MIN_TEMP,
      MAX_TEMP,
      TEMP_STEP
    );
    if (next !== currentTemp) currentTemp = next;
  }

  // --- 湿度 ---
  if (currentMode === "dehumidifying") {
    const next = clampValue(
      currentHumidity + stepDiff * HUMIDITY_STEP,
      MIN_HUMIDITY,
      MAX_HUMIDITY,
      HUMIDITY_STEP
    );
    if (next !== currentHumidity) currentHumidity = next;
  }

  // --- 送風 ---
  if (currentMode === "perflation") {
    const next = currentPerflationIndex + stepDiff;
    if (next >= 0 && next < PERFLATION_MODES.length) {
      currentPerflationIndex = next;
    }
  }

  updateDisplay();
}

// =========================
// 外部モード切替時に呼ぶ関数
// =========================
function onModeChanged() {
  updateDisplay();
}

// =========================
// ボタンイベント
// =========================
btnDown.addEventListener("click", () => changeValue(-1));
btnUp.addEventListener("click", () => changeValue(1));

// =========================
// 初期化
// =========================
currentTemp = clampValue(TEMP_INITIAL, MIN_TEMP, MAX_TEMP, TEMP_STEP);
currentHumidity = clampValue(
  HUMIDITY_INITIAL,
  MIN_HUMIDITY,
  MAX_HUMIDITY,
  HUMIDITY_STEP
);
currentPerflationIndex = PERFLATION_INITIAL_INDEX;

updateDisplay();

/******************************************
 * A.I.自動運転モードのオーバーレイ切替処理
 ******************************************/
const overlayUpdate = () => {
  const overlay = document.querySelector(".wind-overlay");
  getJsonValue("currentMode")?.includes("ai-auto")
    ? overlay.classList.remove("d-none")
    : overlay.classList.add("d-none");
};

/******************************************
 * BS5 モーダルフォーカス解除
 ******************************************/
window.addEventListener("hide.bs.modal", () => {
  document.activeElement.blur();
});
