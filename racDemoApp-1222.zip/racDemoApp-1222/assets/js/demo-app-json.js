const initialAppData = {
  "currentPage": "basic", // 表示画面
  "currentMode": "cooling", // 運転モード（cooling, dehumidifying, heating, perflation, ai-auto-cooling, ai-auto-heating）

// 運転モード選択ボタン状態, 温度・湿度・除湿表示
  "driveModeSelectBtn": {
    "cooling": {
      "label": "冷房",
      "icon": "../assets/img/home-icon-btn-cooling.svg",
      "style": "btn-cooling",
      "settingDisplay": "text-cooling"
    },
    "dehumidifying": {
      "label": "除湿",
      "icon": "../assets/img/home-icon-btn-dehumidification.svg",
      "style": "btn-dehumidifying",
      "settingDisplay": "text-dehumidifying"
    },
    "heating": {
      "label": "暖房",
      "icon": "../assets/img/home-icon-btn-heating.svg",
      "style": "btn-heating",
      "settingDisplay": "text-heating"
    },
    "perflation": {
      "label": "送風",
      "icon": "../assets/img/home-icon-btn-perflation.svg",
      "style": "btn-perflation",
      "settingDisplay": "text-perflation"
    },
    "ai-auto-cooling": {
      "label": "A.I.自動(冷房)",
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
      "settingDisplay": "text-ai-auto"
    },
    "ai-auto-heating": {
      "label": "A.I.自動(暖房)",
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
      "settingDisplay": "text-ai-auto"
    }
  },

  // フッターアイコン状態
  footerStatus: {
    mymu: {
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "iconActive": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
    },
    basic: {
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "iconActive": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
    },
    schedule: {
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "iconActive": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
    },
    other: {
      "icon": "../assets/img/home-icon-btn-ai-auto.svg",
      "iconActive": "../assets/img/home-icon-btn-ai-auto.svg",
      "style": "btn-ai-auto",
    }
  },

  footerIconStatus: {
    mymu: "../assets/img/icon-footer-mymu.svg",
    basic: "../assets/img/icon-footer-basic-active.svg",
    schedule: "../assets/img/icon-footer-schedule.svg",
    other: "../assets/img/icon-footer-other.svg",
  },
  // スケジュール設定
  schedule: [
    {
      id: 1,
      name: "朝の運転",
      startTime: "07:00",
      dayOfTheWeek: {
        mon: true,
        tue: true,
        wed: true,
        thu: true,
        fri: true,
        sat: false,
        sun: false,
      },
      drive: true,
      mode: "cooling",
      setValue: 24,
    },
  ],
  footerTextStatus: {
    mymu: "footer-text",
    basic: "footer-text",
    schedule: "footer-text",
    other: "footer-text",
  },

  // 運転／停止ボタン
  modalDrive: {
    // true ⇔ false
    isRunning: true,
    label: "停止",
  },
};

function storeJsonData() {
  try {
    sessionStorage.setItem("appData", JSON.stringify(initialAppData));
    // リダイレクト先に移動
    window.location.href = "./home/";
  } catch (error) {
    showAlert("JSONデータの保存に失敗しました。", "error");
  }
}

storeJsonData();
